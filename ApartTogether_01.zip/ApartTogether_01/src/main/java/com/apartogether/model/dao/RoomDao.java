package com.apartogether.model.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.apartogether.model.bean.Room;
import com.apartogether.utility.Paging;

public class RoomDao extends SuperDao{

	public List<Room> selectInfo(Paging pageInfo) throws Exception{ //방정보를 보여줌(방번호 , 주문시간, 방제목, 위치)
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		
		String sql = "SELECT ro.roomno, ro.ordertime, ro.roomname, pl.place, st.stname, st.category ";
		sql += " FROM room ro INNER JOIN placetable pl ON ro.placecode = pl.placecode";
		sql += " INNER JOIN store st ON ro.stno = st.stno";
		
		
		
		conn = super.getConnection();
		pstmt=conn.prepareStatement(sql);

		
		rs= pstmt.executeQuery();
		
		List<Room> lists = new ArrayList<Room>();
		
		while(rs.next()) {
			lists.add(getBeanData(rs));
		}
		
		if(rs != null) {rs.close();}
		if(pstmt != null) {pstmt.close();}
		if(conn != null) {conn.close();}
	
		return lists;
	}

	private Room getBeanData(ResultSet rs) throws Exception{
		Room bean = new Room();
		
		bean.setCategory(rs.getString("category"));
		bean.setOrdertime(rs.getString("ordertime"));
		bean.setPlace(rs.getString("place"));
		bean.setStname(rs.getString("stname"));
		bean.setRoomname(rs.getString("roomname"));
		bean.setRoomno(rs.getInt("roomno"));

		
		return bean;
	}

	public int GetTotalRecordCount() throws Exception {
		// 테이블의 총 행개수를 구합니다.
		String sql = " select count(*) as cnt from room " ;
		
		PreparedStatement pstmt = null ;
		ResultSet rs = null ;
		
		conn = super.getConnection() ;
		pstmt = conn.prepareStatement(sql) ;
		
		rs = pstmt.executeQuery() ; 
		
		int cnt = -1 ;
		
		if(rs.next()) {
			cnt = rs.getInt("cnt") ;
		}
		
		if(rs!=null) {rs.close();}
		if(pstmt!=null) {pstmt.close();}
		if(conn!=null) {conn.close();}
		
		return cnt;
	}	
	
}
